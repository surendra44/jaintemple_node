export const ERROR_MESSAGE = {
  ADMIN:{
    NOT_FOUND: "Admin not found"
  },
  
  NOT_FOUND: "Data not found",
  DONATION:{
    Delete:"The Donation ID you are trying delete is not Found",
    GetID:"The Donation ID you are trying Find is not Found"
  },
  DONAR:{
    Delete:"The Donar ID you are trying delete is not Found",
    GetID:"The Donar ID you are trying Find is not Found"
  },

  USER:{
    Delete:"The User ID you are trying delete is not Found",
    GetID:"The User ID you are trying Find is not Found"
  },

};
