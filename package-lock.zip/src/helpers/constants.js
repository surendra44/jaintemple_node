export const NODE_ENVIRONMENT = {
  DEVO: "development",
  TEST: "test",
  PROD: "production",
};
export const Role_TYPE = {
  User: "user",
  Admin: "admin",
  SuperAdmin: "superadmin"
};