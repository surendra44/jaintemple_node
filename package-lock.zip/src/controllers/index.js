module.exports.userController = require('./user.controller');
module.exports.roleController = require('./role.controller');
module.exports.donorController  = require('./donor.controller');
module.exports.templeController  = require('./temple.controller');
module.exports.eventDetailController  = require('./eventDetail.controller');
module.exports.donationController  = require('./donation.controller');
module.exports.expenseCategory  = require('./expenseCategory.controller');
module.exports.expenseController  = require('./expense.controller');
module.exports.dailyEventController  = require('./dailyEvent.controller');
module.exports.jainBookController  = require('./jainBooks.controller');


