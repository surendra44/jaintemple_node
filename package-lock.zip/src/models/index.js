module.exports.User = require('./user');
module.exports.Role = require('./role');
module.exports.Donar = require('./donar');
module.exports.Family = require('./family');
module.exports.ExpensesCategory = require('./expenseCategory');
module.exports.EventDetail = require('./eventDetail');
module.exports.DailyEventCategory = require('./dailyCategory');
module.exports.JainBook = require('./jainBooks');